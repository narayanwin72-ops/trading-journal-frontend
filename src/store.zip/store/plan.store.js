import { create } from "zustand";
import { persist } from "zustand/middleware";

/*
  Plan Structure:
  {
    id: string
    name: string
    description: string
    isActive: boolean
    createdAt: number
  }
*/

export const usePlanStore = create(
  persist(
    (set, get) => ({
      plans: [],

      /* ================= INIT CHECK ================= */
      ensureFreePlan: () => {
        const plans = get().plans;
        const hasFree = plans.some(
          (p) => p.id === "FREE"
        );

        if (!hasFree) {
          set({
            plans: [
              {
                id: "FREE",
                name: "FREE",
                description: "Default free plan",
                isActive: true,
                createdAt: Date.now(),
              },
              ...plans,
            ],
          });
        }
      },

      // ➕ Add new plan
      addPlan: ({ name, description }) =>
        set((state) => ({
          plans: [
            ...state.plans,
            {
              id: Date.now().toString(),
              name,
              description,
              isActive: true,
              createdAt: Date.now(),
            },
          ],
        })),

      // ✏️ Edit existing plan
      updatePlan: (id, updates) =>
        set((state) => ({
          plans: state.plans.map((plan) =>
            plan.id === id
              ? { ...plan, ...updates }
              : plan
          ),
        })),

      // ❌ Delete plan (FREE protected)
      deletePlan: (id) =>
        set((state) => ({
          plans:
            id === "FREE"
              ? state.plans
              : state.plans.filter(
                  (plan) => plan.id !== id
                ),
        })),

      // 🔁 Toggle Active / Inactive (FREE always active)
      togglePlanStatus: (id) =>
        set((state) => ({
          plans: state.plans.map((plan) =>
            plan.id === "FREE"
              ? plan
              : plan.id === id
              ? {
                  ...plan,
                  isActive: !plan.isActive,
                }
              : plan
          ),
        })),

      // 🔍 Get plan by id
      getPlanById: (id) =>
        get().plans.find((p) => p.id === id),
    }),
    {
      name: "admin-plan-store",

      /* ================= AFTER REHYDRATE ================= */
      onRehydrateStorage: () => (state) => {
        state?.ensureFreePlan();
      },
    }
  )
);
