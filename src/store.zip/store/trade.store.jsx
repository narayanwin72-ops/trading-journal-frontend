import { create } from "zustand";

/* ================= HELPERS ================= */

function getCurrentUserId() {
  try {
    const user = JSON.parse(localStorage.getItem("auth_user"));
    return user?.user_id || null;
  } catch {
    return null;
  }
}

function getUserTradesKey() {
  const userId = getCurrentUserId();
  return userId ? `user_trades_${userId}` : null;
}

function loadTrades() {
  const key = getUserTradesKey();
  if (!key) return [];

  try {
    return JSON.parse(localStorage.getItem(key)) || [];
  } catch {
    localStorage.removeItem(key);
    return [];
  }
}

function saveTrades(trades) {
  const key = getUserTradesKey();
  if (!key) return;
  localStorage.setItem(key, JSON.stringify(trades));
}

/* ================= STORE ================= */

export const useTrades = create((set, get) => ({
  trades: loadTrades(),

  editTradeId: null,
  editTradeType: null,

  /* ================= ADD ================= */
  addTrade: (trade) => {
    const trades = get().trades;

    const finalTrade = {
      id: Date.now(),
      ...trade,
      createdAt: new Date().toLocaleString(),
    };

    const updated = [finalTrade, ...trades];

    saveTrades(updated);
    set({ trades: updated });
  },

  /* ================= UPDATE ================= */
  updateTrade: (id, updatedTrade) => {
    const trades = get().trades.map((t) =>
      t.id === id ? { ...t, ...updatedTrade } : t
    );

    saveTrades(trades);
    set({ trades });
  },

  /* ================= DELETE ================= */
  deleteTrade: (id) => {
    const trades = get().trades.filter((t) => t.id !== id);

    saveTrades(trades);
    set({ trades });
  },

  /* ================= EDIT FLOW ================= */
  setEditTradeId: (id, tradeType) =>
    set({
      editTradeId: id,
      editTradeType: tradeType,
    }),

  clearEditTradeId: () =>
    set({
      editTradeId: null,
      editTradeType: null,
    }),

  /* ================= CRITICAL ================= */
  refreshTradesForUser: () => {
    set({ trades: loadTrades() });
  },
}));
