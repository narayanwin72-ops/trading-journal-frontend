import { create } from "zustand";
import {
  loadBrokerCapital,
  saveBrokerCapital,
} from "../utils/brokerCapitalStorage";

/* =====================================================
   BROKER CAPITAL STORE (USER-WISE)
===================================================== */

export const useBrokerCapital = create((set, get) => ({
  /* ================= STATE ================= */
  transactions: [],

  /* ================= INIT ================= */
  refreshForUser: () => {
    const data = loadBrokerCapital();

    set({
      transactions: Array.isArray(data) ? data : [],
    });
  },

  /* ================= ADD ================= */
  addTransaction: (tx) => {
    const transactions = get().transactions;

    const updated = [tx, ...transactions];

    set({ transactions: updated });
    saveBrokerCapital(updated);
  },

  /* ================= UPDATE ================= */
  updateTransaction: (index, updatedTx) => {
    const transactions = get().transactions.map((t, i) =>
      i === index ? { ...t, ...updatedTx } : t
    );

    set({ transactions });
    saveBrokerCapital(transactions);
  },

  /* ================= DELETE ================= */
  deleteTransaction: (index) => {
    const transactions = get().transactions.filter((_, i) => i !== index);

    set({ transactions });
    saveBrokerCapital(transactions);
  },
}));
