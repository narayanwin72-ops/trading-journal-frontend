import { create } from "zustand";

/*
  Trade Entry Feature Store
  ------------------------
  - Admin Trade Entry Control state persist করে
  - Plan logic = plan.id
  - Plan name শুধু UI দেখানোর জন্য
*/

const STORAGE_KEY = "TRADE_ENTRY_FEATURES";

/* 🔹 Default features (initial load only) */
const DEFAULT_FEATURES = [
  {
    featureId: "OPTION_INTRADAY_TAB",
    label: "Option Intraday Tab",
    allowedPlans: [],
  },

  { featureId: "OPTION_INTRADAY_DATE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_TIME", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_TIME_RANGE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_UNDERLYING", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_EXPIRY", allowedPlans: [] },

  { featureId: "OPTION_INTRADAY_STRIKE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_OPTION_TYPE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_POSITION", allowedPlans: [] },

  { featureId: "OPTION_INTRADAY_ENTRY_PRICE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_STOP_LOSS", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_TARGET", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_QUANTITY", allowedPlans: [] },

  { featureId: "OPTION_INTRADAY_STRATEGY", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_TIMEFRAME", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_ENTRY_REASON", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_CONFIDENCE", allowedPlans: [] },

  { featureId: "OPTION_INTRADAY_EXIT_PRICE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_EXIT_TIME", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_EXIT_REASON", allowedPlans: [] },

  { featureId: "OPTION_INTRADAY_BROKERAGE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_REMARKS", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_CHART_IMAGE", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_BROKER", allowedPlans: [] },
  { featureId: "OPTION_INTRADAY_CAPITAL", allowedPlans: [] },
];

export const useTradeEntryFeatureStore = create((set, get) => ({
  /* ================= STATE ================= */
  features:
    JSON.parse(localStorage.getItem(STORAGE_KEY)) ||
    DEFAULT_FEATURES,

  /* ================= ACTIONS ================= */

  // Admin panel checkbox toggle
  updateAllowedPlans(featureId, plans) {
    const updated = get().features.map((f) =>
      f.featureId === featureId
        ? { ...f, allowedPlans: plans }
        : f
    );

    localStorage.setItem(
      STORAGE_KEY,
      JSON.stringify(updated)
    );

    set({ features: updated });
  },

  // User-side feature check
  canUse(featureId, planId) {
    if (!featureId || !planId) return false;

    const feature = get().features.find(
      (f) => f.featureId === featureId
    );

    if (!feature) return false;

    return feature.allowedPlans.includes(planId);
  },
}));
