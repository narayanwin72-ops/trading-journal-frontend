import { create } from "zustand";
import { persist } from "zustand/middleware";

/*
  USER LOG STRUCTURE (ADMIN SIDE)

  user = {
    id: string
    registrationDate: number
    name: string
    email: string
    phone: string

    status: "ACTIVE" | "BLOCKED"

    plan: {
      planId: string
      planName: string
      variantId: string
      variantName: string
      startDate: number
      expiryDate: number
    }

    stats: {
      totalTrades: number
      netPnl: number
    }

    payments: [
      {
        id: string
        date: number
        amount: number
        gateway: "COSMOFEED" | "RAZORPAY"
        referenceId: string
      }
    ]

    extraFields: {
      [key: string]: string
    }
  }
*/

export const useUserLogStore = create(
  persist(
    (set, get) => ({
      users: [],

      /* ➕ ADD USER (on registration) */
      addUser: (user) =>
        set((state) => ({
          users: [
            ...state.users,
            {
              id: Date.now().toString(),
              registrationDate: Date.now(),
              status: "ACTIVE",

              stats: {
                totalTrades: 0,
                netPnl: 0,
              },

              payments: [],

              extraFields: {},

              ...user,
            },
          ],
        })),

      /* 🔄 UPDATE BASIC USER INFO */
      updateUser: (id, updates) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id ? { ...u, ...updates } : u
          ),
        })),

      /* 🔐 BLOCK / UNBLOCK USER */
      setUserStatus: (id, status) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id ? { ...u, status } : u
          ),
        })),

      /* 📦 ASSIGN / UPDATE PLAN */
      updateUserPlan: (id, planData) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id
              ? {
                  ...u,
                  plan: {
                    ...u.plan,
                    ...planData,
                  },
                }
              : u
          ),
        })),

      /* ⏳ EXTEND / REDUCE EXPIRY */
      updateExpiry: (id, newExpiryDate) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id
              ? {
                  ...u,
                  plan: {
                    ...u.plan,
                    expiryDate: newExpiryDate,
                  },
                }
              : u
          ),
        })),

      /* 💰 ADD PAYMENT ENTRY */
      addPayment: (id, payment) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id
              ? {
                  ...u,
                  payments: [
                    ...u.payments,
                    {
                      id: Date.now().toString(),
                      date: Date.now(),
                      ...payment,
                    },
                  ],
                }
              : u
          ),
        })),

      /* 📊 UPDATE USER STATS */
      updateUserStats: (id, stats) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id
              ? {
                  ...u,
                  stats: {
                    ...u.stats,
                    ...stats,
                  },
                }
              : u
          ),
        })),

      /* 🔍 GET HELPERS (for future filters) */
      getActiveUsers: () =>
        get().users.filter((u) => u.status === "ACTIVE"),

      getBlockedUsers: () =>
        get().users.filter((u) => u.status === "BLOCKED"),

      getExpiredUsers: () =>
        get().users.filter(
          (u) => u.plan && u.plan.expiryDate < Date.now()
        ),
    }),
    {
      name: "admin-user-log-store",
    }
  )
);
